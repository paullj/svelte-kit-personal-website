import{default as t}from"../components/pages/(list)/_layout.svelte-699cb0be.js";export{t as component};
