import{default as t}from"../components/pages/(item)/posts/_slug_/_page.svelte-4a153aec.js";const e=!0;export{t as component,e as server};
