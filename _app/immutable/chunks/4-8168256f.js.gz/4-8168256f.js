import{default as t}from"../components/pages/(item)/posts/_slug_/_page.svelte-e31d0cf1.js";const e=!0;export{t as component,e as server};
