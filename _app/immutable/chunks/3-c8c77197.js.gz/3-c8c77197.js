import{default as t}from"../components/pages/(list)/_layout.svelte-a48fcd8a.js";export{t as component};
