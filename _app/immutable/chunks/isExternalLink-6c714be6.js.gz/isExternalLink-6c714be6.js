const s=t=>t.startsWith("mailto:"),a=t=>t.startsWith("https://")||t.startsWith("http://"),i=t=>!s(t)&&!a(t)&&!t.startsWith("#");export{s as a,i as b,a as i};
