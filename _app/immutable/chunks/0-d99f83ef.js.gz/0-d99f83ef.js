import{_ as r}from"./_layout-1daba58d.js";import{default as t}from"../components/pages/_layout.svelte-31515c2a.js";export{t as component,r as shared};
