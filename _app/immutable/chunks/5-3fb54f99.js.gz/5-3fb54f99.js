import{default as t}from"../components/pages/(list)/_page.svelte-64030051.js";const e=!0;export{t as component,e as server};
