import{default as t}from"../components/error.svelte-b14b1fb3.js";export{t as component};
