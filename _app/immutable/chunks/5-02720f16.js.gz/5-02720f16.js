import{default as t}from"../components/pages/(list)/_page.svelte-3173bfc9.js";const e=!0;export{t as component,e as server};
