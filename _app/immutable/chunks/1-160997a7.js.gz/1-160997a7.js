import{default as t}from"../components/error.svelte-ae162408.js";export{t as component};
