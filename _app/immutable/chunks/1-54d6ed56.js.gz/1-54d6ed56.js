import{default as t}from"../components/error.svelte-7b173709.js";export{t as component};
