import{default as t}from"../components/pages/(list)/about/_page.svelte-1a0c355d.js";const e=!0;export{t as component,e as server};
