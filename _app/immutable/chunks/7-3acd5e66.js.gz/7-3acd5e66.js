import{default as t}from"../components/pages/(list)/page/_page_integer_/_page.svelte-64d4ae3b.js";const e=!0;export{t as component,e as server};
