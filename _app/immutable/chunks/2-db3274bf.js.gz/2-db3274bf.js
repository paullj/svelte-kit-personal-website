import{_ as r}from"./_layout-b4ee359a.js";import{default as t}from"../components/pages/(item)/posts/_layout.svelte-57b7cf2f.js";export{t as component,r as shared};
