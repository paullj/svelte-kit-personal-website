const s=5,e=2,t={width:1200,height:630},o="paullj",a="svelte-kit-personal-website";export{a,o as g,t as o,s as p,e as s};
