import{default as t}from"../components/pages/(list)/about/_page.svelte-aaaa9c64.js";const e=!0;export{t as component,e as server};
