import{default as t}from"../components/pages/(list)/page/_page_integer_/_page.svelte-39f0b2de.js";const e=!0;export{t as component,e as server};
