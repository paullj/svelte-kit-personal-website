import{default as t}from"../components/pages/(list)/_page.svelte-d3796f71.js";const e=!0;export{t as component,e as server};
