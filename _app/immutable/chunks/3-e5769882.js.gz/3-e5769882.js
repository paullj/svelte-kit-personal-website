import{default as t}from"../components/pages/(list)/_layout.svelte-a76c0388.js";export{t as component};
