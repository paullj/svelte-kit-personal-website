import{_ as r}from"./_layout-b4ee359a.js";import{default as t}from"../components/pages/(item)/posts/_layout.svelte-d86bee03.js";export{t as component,r as shared};
